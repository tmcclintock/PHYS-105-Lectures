//Kyle Massingill
//PHYS 105
//to compile: $gcc hello.c -o hello.exe
//to run: $hello.exe
//Due before next class
//open fire fox from terminal not from the desktop

#include <stdio.h>

int main()
{
  printf("Must Get an A!");
}
