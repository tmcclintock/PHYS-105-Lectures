//Kirsten Cafarella
//PHYS 105
//This is a comment
//I hope this is what you meant
//to compile: $gcc hello.c -o hello.exe
//to run: $hello.exe

#include <stdio.h>

int main()
{
  printf("LI represent. I work in Huntington.");
}
