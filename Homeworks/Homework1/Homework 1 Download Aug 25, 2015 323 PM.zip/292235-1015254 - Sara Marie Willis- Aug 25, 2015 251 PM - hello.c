//Sara Willis
//Phys 105
//I'm including a comment here for practice
//to compile: $gcc hello.c -o hello.exe
//to run: $hello.exe
#include <stdio.h>
int main()
{
  printf("Hello world! My name is Hal. It's a good thing I'm not in a space station.");
}
