//Joseph Foster 
//phys 105 
//to compile: $gcc homework.c -o homework.exe
//to run: $homework.exe 

#include <stdio.h>

int main()
{
  printf("This is my first assignment!");
}

