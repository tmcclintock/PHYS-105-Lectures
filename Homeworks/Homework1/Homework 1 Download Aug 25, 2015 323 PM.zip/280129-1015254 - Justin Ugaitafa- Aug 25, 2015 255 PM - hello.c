//Justin Ugaitafa
//PHYS 105
//to compile: $gcc hello.c -o supercalifragelisticespealidocius.exe
//to run: $supercalifragelisticespealidocious.exe

#include <stdio.h>

int main()
{
  printf("Supercalifragelisticespealidocious!");
}
