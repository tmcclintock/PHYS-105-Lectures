//Henry Esteban
//PHY 105
//to compile: $gcc hello.c -o hello.exe
//to run: $hello.exe

#include <stdio.h>

int main () //This is the main method
{
  printf("Error 404"); //Words in parentheses will be ouputted on the termal screen once promted.
}
