//Ryan Dietzenbach
//PHYS 105
//to compile:$gcc speak.c -o speak.exe
//to run: $speak.exe

#include <stdio.h>

int main ()
{
  printf("hello Ryan!");
}
