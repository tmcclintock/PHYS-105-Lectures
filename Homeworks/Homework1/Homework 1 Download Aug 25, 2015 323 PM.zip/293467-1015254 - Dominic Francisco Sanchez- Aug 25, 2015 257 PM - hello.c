// Dominic Sanchez
// PHYS 105
// to compile: $gcc hello.c -o hello.exe
// to run: $hello.c -o hello.exe
// Exoplanet XO-2b is better than Exoplanet HD209458b 

#include <stdio.h>

int main() 
{
  printf("XO-2b is still better than HD209458b");
}
