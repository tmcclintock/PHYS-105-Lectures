//Jacob Lewis
//PHYS 105
//to compile: $gcc hello.c -o hello.exe
//gcc is the name of the compiler
//to run: $hello.exe
//these comments are absolutely necessary to understanding a program

#include <stdio.h>

int main ()
{
  printf("I want an a in this class!");
}
