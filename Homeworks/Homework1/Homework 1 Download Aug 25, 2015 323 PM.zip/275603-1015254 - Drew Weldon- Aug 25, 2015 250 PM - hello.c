//Drew Weldon
//PHYS 105
//to complete: $gcc hello.c -o hello.exe
//to run: $hello.exe

#include <stdio.h>

int main()
{
  printf("I want to be the very best like no one every was!!");
}
