//Jiatian Wang
//PHYS 105
//to compile: $gcc hello.c -o hello.exe
//to run: $hello.exe

#include <stdio.h>

int main()
{
  printf("I love quantum mechanics, cuz quantum computer is amazing, M string theory is also fantasty!!");
}

