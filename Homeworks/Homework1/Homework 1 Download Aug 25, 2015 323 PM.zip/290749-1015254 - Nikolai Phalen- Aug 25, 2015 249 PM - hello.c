//Nikolai Phalen
//PHYS 105
//to compile: $gcc hello.c -o hello.exe
//to run: $hello.exe

#include <stdio.h>

int main ()
{
  printf("Hello world!");
}
 
