//Jon Khacheryan
//Phys 105
//Aug 25, 2015
//to compile: $gcc hello.c -o hello.exe
//to run: $hello.exe

#include <stdio.h>

int main() 

{printf("How many physicists with a specialty in relativity does it take to screw in a light bulb? 2 one to hold the light bulb and another to twist the universe.");

    }
